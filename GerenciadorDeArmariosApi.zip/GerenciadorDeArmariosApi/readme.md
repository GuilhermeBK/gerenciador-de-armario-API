#feitos até agora:

##Controller para inserir alunos e armarios

##Repository para pegar e inserir dados no banco

##Entidades representando o banco (mysql)

#A FAZER: Eventos, restante dos controllers e envio de email por evento e controle de logs