package com.br.gerenciadordearmariosapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorDeArmariosApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
